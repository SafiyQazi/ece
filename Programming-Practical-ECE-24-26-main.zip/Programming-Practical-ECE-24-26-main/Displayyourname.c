#include <stdio.h>
//This code is for to display your name
int main() {
    printf("My name is Farhan.\n");
    return 0;
}